#include "object.h"

void Object::Draw()
{
}

void Object::InitRenderData()
{
}
